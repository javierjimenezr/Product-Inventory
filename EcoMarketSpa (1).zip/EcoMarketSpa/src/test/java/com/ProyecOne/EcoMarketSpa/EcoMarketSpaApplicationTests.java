package com.ProyecOne.EcoMarketSpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoMarketSpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
