package com.ProyecOne.EcoMarketSpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcoMarketSpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcoMarketSpaApplication.class, args);
	}

}
